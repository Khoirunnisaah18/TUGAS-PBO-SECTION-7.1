
public class Main {
	public static void main(String[] args) {
		LongTermSavings savingBond = new LongTermSavings(7); 
		savingBond.setInitialAmount(30000);
		System.out.println("Total Pendapatan:Rp " + savingBond.calculateFutureValue());
	}
}
