public class LongTermSavings {
    private double initialAmount;
    private int termInMonths;
    private double monthlyInterest;

    public LongTermSavings(int months) {
        setTermInMonths(months);
    }

    private void setTermInMonths(int months) {
        this.termInMonths = months;
        this.monthlyInterest = computeYearlyInterestRate();
    }
    
    public void setInitialAmount(double initialAmount) {
        this.initialAmount = initialAmount;
    }
    
    public double calculateFutureValue(){
        double totalAmount = initialAmount;
        for (int i = 0; i < termInMonths; i++) {
            double interestReceived = totalAmount * (monthlyInterest/ 100);
            totalAmount += interestReceived; 
        }
        return totalAmount;
    }

    private double computeYearlyInterestRate() {
        if (termInMonths >= 0 && termInMonths <= 11) {
            return 0.5;
        } else if (termInMonths <= 23) {
            return 1.0;
        } else if (termInMonths <= 35) {
            return 1.5;
        } else if (termInMonths <= 47) {
            return 2.0;
        } else if (termInMonths <= 60) {
            return 2.5;
        } else {
            throw new IllegalArgumentException("Term should be between 1 to 60 months");
        }
    }


    public int getTermInMonths() {
        return termInMonths;
    }

    public double getMonthlyInterest() {
        return monthlyInterest;
    }
}
